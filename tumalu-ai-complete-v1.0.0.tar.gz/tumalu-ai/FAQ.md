# ❓ FAQ - TUMALU AI

## Perguntas Frequentes

### 🔑 Sobre Token e Autenticação

**Q: O token do Hugging Face é gratuito?**
A: Sim! 100% gratuito. Basta criar uma conta em huggingface.co e gerar um token.

**Q: Preciso pagar para usar as APIs?**
A: Não! As APIs do Hugging Face Spaces são gratuitas com limites de rate.

**Q: Qual a diferença entre token "Read" e "Write"?**
A: Para este app, "Read" é suficiente e mais seguro. "Write" é para criar/modificar modelos.

**Q: Meu token expira?**
A: Não, tokens do Hugging Face não expiram automaticamente. Você pode revogá-los manualmente.

**Q: Posso usar o mesmo token em múltiplos dispositivos?**
A: Sim! O token é vinculado à sua conta, não ao dispositivo.

---

### 🖼️ Sobre Geração de Imagens

**Q: Quanto tempo demora para gerar uma imagem?**
A: Geralmente 5-30 segundos, dependendo da complexidade e carga do servidor.

**Q: Posso gerar imagens de pessoas reais?**
A: Evite gerar imagens de pessoas reais identificáveis. Use descrições genéricas.

**Q: Qual a resolução das imagens geradas?**
A: FLUX.1-schnell gera imagens em 1024x1024 pixels por padrão.

**Q: Posso usar as imagens comercialmente?**
A: Consulte os termos de uso do FLUX.1 no Hugging Face. Geralmente, imagens geradas podem ser usadas comercialmente.

**Q: Posso gerar imagens em português?**
A: Sim, mas prompts em inglês tendem a gerar resultados melhores.

**Q: Quantas imagens posso gerar por dia?**
A: Com token gratuito: ~100 requisições/hora. Sem token: ~10 requisições/hora.

---

### 🎥 Sobre Geração de Vídeos

**Q: Quanto tempo demora para gerar um vídeo?**
A: Entre 2-10 minutos, dependendo da duração do áudio e qualidade da imagem.

**Q: Qual o tamanho máximo dos arquivos?**
A: Recomendamos:
- Imagem: até 5MB
- Áudio: até 10MB

**Q: Posso usar qualquer foto?**
A: Sim, mas funciona melhor com:
- Rosto visível e centralizado
- Boa iluminação
- Fundo neutro
- Resolução mínima 512x512px

**Q: O áudio precisa ser voz humana?**
A: Sim, o lip sync funciona apenas com voz. Música instrumental não funciona.

**Q: Posso usar foto de celebridades?**
A: Tecnicamente sim, mas considere questões éticas e legais de deepfake.

**Q: O vídeo tem marca d'água?**
A: Não, o vídeo gerado é limpo, sem marcas d'água.

---

### 🐛 Problemas Comuns

**Q: Erro "Rate limit exceeded"**
A: Você atingiu o limite de requisições. Aguarde 10-60 minutos e tente novamente.

**Q: Erro "Token inválido"**
A: Verifique se:
- Token começa com `hf_`
- Token foi copiado completamente
- Token tem permissão "Read"

**Q: Erro "Network timeout"**
A: Isso pode acontecer quando:
- Servidor está sobrecarregado
- Sua internet está lenta
- Arquivos são muito grandes
Solução: Tente novamente em alguns minutos.

**Q: Imagem não carrega**
A: 
- Verifique sua conexão
- Tente abrir a URL da imagem diretamente
- Faça download e abra localmente

**Q: Vídeo não é gerado**
A:
- Certifique-se que a imagem tem um rosto visível
- Use áudio com voz clara
- Reduza tamanho dos arquivos
- Tente novamente com arquivos diferentes

**Q: "Nenhum rosto detectado"**
A: A foto precisa ter um rosto claro e visível. Evite:
- Fotos muito escuras
- Rosto coberto por óculos/máscaras
- Rosto muito pequeno na imagem
- Múltiplos rostos (use foto com 1 pessoa)

---

### 💻 Sobre Instalação e Uso

**Q: Preciso instalar algo além do Node.js?**
A: Não! Apenas Node.js 18+ e os pacotes do npm (instalados automaticamente).

**Q: Funciona no Windows/Mac/Linux?**
A: Sim! O projeto funciona em qualquer sistema com Node.js.

**Q: Posso usar em celular?**
A: A interface é responsiva, mas recomendamos desktop para melhor experiência.

**Q: Preciso de GPU?**
A: Não! O processamento é feito nos servidores do Hugging Face, não no seu computador.

**Q: Consome muita internet?**
A:
- Imagens: ~2-5MB por geração
- Vídeos: ~10-50MB por geração

**Q: Posso usar offline?**
A: Não, você precisa de conexão com internet para acessar as APIs.

---

### 🚀 Sobre Deploy e Produção

**Q: Posso fazer deploy em produção?**
A: Sim! Compatível com Vercel, Netlify, Railway, etc.

**Q: Preciso pagar por hosting?**
A: Não necessariamente. Vercel e Netlify oferecem planos gratuitos para Next.js.

**Q: Como escondo meu token em produção?**
A: Use variáveis de ambiente (.env.local) e nunca commite o token no GitHub.

**Q: Quantos usuários simultâneos suporta?**
A: Depende do seu hosting e dos limites de rate do Hugging Face.

---

### 🎨 Personalizações

**Q: Posso mudar as cores da interface?**
A: Sim! Edite `app/globals.css` e `tailwind.config.js`.

**Q: Posso adicionar mais modelos de IA?**
A: Sim! Basta adicionar novas API routes e conectar aos Spaces desejados.

**Q: Posso remover a aba de vídeo?**
A: Sim! Edite `app/page.tsx` e remova o conteúdo da aba de vídeo.

**Q: Posso adicionar autenticação?**
A: Sim! Integre com NextAuth, Clerk, ou similar.

---

### 📊 Desempenho e Limites

**Q: Qual o limite de requisições?**
A: Com token gratuito do HF:
- ~100 requisições/hora
- ~1000 requisições/dia

**Q: Posso aumentar os limites?**
A: Sim, fazendo upgrade para plano PRO do Hugging Face.

**Q: O que acontece se exceder o limite?**
A: Você recebe erro 429 (Too Many Requests) e precisa aguardar.

**Q: Posso cachear resultados?**
A: Sim! Salve imagens/vídeos localmente ou em cloud storage.

---

### 🔒 Segurança e Privacidade

**Q: Meus dados são salvos?**
A: No Hugging Face, sim temporariamente. No app, não salvamos nada.

**Q: O token fica exposto?**
A: Não se você usar `.env.local`. Na interface, use localStorage com cautela.

**Q: É seguro usar?**
A: Sim, mas nunca compartilhe seu token publicamente.

**Q: Posso deletar conteúdo gerado?**
A: Conteúdo gerado pode ser automaticamente deletado pelo HF após 24h.

---

### 🆘 Suporte

**Q: Onde reportar bugs?**
A: Abra uma issue no repositório GitHub do projeto.

**Q: Onde pedir ajuda?**
A: 
1. Leia este FAQ
2. Consulte TESTING.md
3. Verifique logs do console
4. Pesquise no fórum do Hugging Face

**Q: Tem Discord/comunidade?**
A: Este é um projeto open-source. Contribuições são bem-vindas!

---

### 📚 Recursos Adicionais

**Q: Onde aprender mais sobre os modelos?**
A:
- FLUX: https://huggingface.co/black-forest-labs/FLUX.1-schnell
- LivePortrait: https://huggingface.co/spaces/KwaiVGI/LivePortrait

**Q: Tem tutorial em vídeo?**
A: Consulte o README.md para instruções passo a passo.

**Q: Posso contribuir com o projeto?**
A: Sim! Pull requests são bem-vindos.

---

## 💡 Dicas Pro

1. **Melhores Prompts**: Seja específico e descritivo
2. **Qualidade de Imagem**: Use fotos bem iluminadas
3. **Áudio Limpo**: Grave em ambiente silencioso
4. **Paciência**: Vídeos demoram mais, é normal
5. **Teste Primeiro**: Experimente com arquivos pequenos
6. **Salve Resultados**: Faça backup do que gostar
7. **Rate Limits**: Distribua requisições ao longo do tempo
8. **Resolução**: Imagens maiores nem sempre = melhores resultados

---

**Ainda tem dúvidas?** Consulte a documentação oficial do Hugging Face ou abra uma issue! 🚀
