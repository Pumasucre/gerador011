import { NextRequest, NextResponse } from 'next/server';
import { Client } from '@gradio/client';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const image = formData.get('image') as File;
    const audio = formData.get('audio') as File;
    const token = formData.get('token') as string;

    if (!image || !audio || !token) {
      return NextResponse.json(
        { error: 'Imagem, áudio e token são obrigatórios' },
        { status: 400 }
      );
    }

    console.log('🚀 Iniciando geração de vídeo com LivePortrait...');
    console.log('🖼️ Imagem:', image.name, image.type, image.size, 'bytes');
    console.log('🎵 Áudio:', audio.name, audio.type, audio.size, 'bytes');

    // Converter arquivos para Buffer
    const imageBuffer = Buffer.from(await image.arrayBuffer());
    const audioBuffer = Buffer.from(await audio.arrayBuffer());

    // Conectar ao Space do Hugging Face
    const client = await Client.connect('KwaiVGI/LivePortrait', {
      hf_token: token,
    });

    console.log('✅ Conectado ao Space LivePortrait');

    // Criar Blob para upload
    const imageBlob = new Blob([imageBuffer], { type: image.type });
    const audioBlob = new Blob([audioBuffer], { type: audio.type });

    // Fazer a predição - LivePortrait usa o endpoint /run
    const result = await client.predict('/run', {
      source_image: imageBlob,
      driving_audio: audioBlob,
      flag_relative_motion: true,
      flag_do_crop: true,
      flag_remap_input: true,
    });

    console.log('✅ Vídeo gerado com sucesso');
    console.log('📦 Resultado:', result);

    // O resultado vem em result.data
    const videoData = result.data;

    if (!videoData || !videoData[0]) {
      throw new Error('Nenhum vídeo foi gerado');
    }

    // O vídeo vem como objeto com url
    const videoUrl = videoData[0]?.url || videoData[0];

    return NextResponse.json({
      success: true,
      videoUrl: videoUrl,
    });

  } catch (error: any) {
    console.error('❌ Erro ao gerar vídeo:', error);
    return NextResponse.json(
      {
        error: error.message || 'Erro ao gerar vídeo',
        details: error.toString(),
      },
      { status: 500 }
    );
  }
}

export const config = {
  api: {
    bodyParser: false,
  },
};
