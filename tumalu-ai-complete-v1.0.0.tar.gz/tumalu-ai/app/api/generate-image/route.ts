import { NextRequest, NextResponse } from 'next/server';
import { Client } from '@gradio/client';

export async function POST(request: NextRequest) {
  try {
    const { prompt, token } = await request.json();

    if (!prompt || !token) {
      return NextResponse.json(
        { error: 'Prompt e token são obrigatórios' },
        { status: 400 }
      );
    }

    console.log('🚀 Iniciando geração de imagem com FLUX.1-schnell...');
    console.log('📝 Prompt:', prompt);

    // Conectar ao Space do Hugging Face
    const client = await Client.connect('black-forest-labs/FLUX.1-schnell', {
      hf_token: token,
    });

    console.log('✅ Conectado ao Space FLUX.1-schnell');

    // Fazer a predição
    const result = await client.predict('/infer', {
      prompt: prompt,
      seed: Math.floor(Math.random() * 1000000),
      randomize_seed: true,
      width: 1024,
      height: 1024,
      num_inference_steps: 4,
    });

    console.log('✅ Imagem gerada com sucesso');
    console.log('📦 Resultado:', result);

    // O resultado vem em result.data
    const imageData = result.data;

    if (!imageData || !imageData[0]) {
      throw new Error('Nenhuma imagem foi gerada');
    }

    // A imagem vem como objeto com url
    const imageUrl = imageData[0]?.url || imageData[0];

    return NextResponse.json({
      success: true,
      imageUrl: imageUrl,
      prompt: prompt,
    });

  } catch (error: any) {
    console.error('❌ Erro ao gerar imagem:', error);
    return NextResponse.json(
      {
        error: error.message || 'Erro ao gerar imagem',
        details: error.toString(),
      },
      { status: 500 }
    );
  }
}

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '10mb',
    },
  },
};
