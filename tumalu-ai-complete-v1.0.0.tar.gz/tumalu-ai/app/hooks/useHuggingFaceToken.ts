'use client';

import { useState, useEffect } from 'react';

const TOKEN_STORAGE_KEY = 'tumalu_ai_hf_token';

export function useHuggingFaceToken() {
  const [token, setToken] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  // Carregar token do localStorage na montagem
  useEffect(() => {
    const savedToken = localStorage.getItem(TOKEN_STORAGE_KEY);
    if (savedToken) {
      setToken(savedToken);
    }
    setIsLoaded(true);
  }, []);

  // Salvar token no localStorage quando mudar
  const saveToken = (newToken: string) => {
    setToken(newToken);
    if (newToken) {
      localStorage.setItem(TOKEN_STORAGE_KEY, newToken);
    } else {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  };

  // Limpar token
  const clearToken = () => {
    setToken('');
    localStorage.removeItem(TOKEN_STORAGE_KEY);
  };

  // Validar formato do token
  const isValidToken = (tokenToValidate: string = token) => {
    return tokenToValidate.startsWith('hf_') && tokenToValidate.length > 10;
  };

  return {
    token,
    saveToken,
    clearToken,
    isValidToken,
    isLoaded
  };
}
