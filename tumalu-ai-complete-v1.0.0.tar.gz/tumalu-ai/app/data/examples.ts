export const imagePromptExamples = [
  {
    category: 'Influenciadores',
    prompts: [
      'Professional influencer holding a smartphone, studio lighting, high quality',
      'Beautiful influencer with product in hand, modern background, professional photo',
      'Lifestyle influencer in casual outfit, holding a laptop, bright natural light',
      'Fashion influencer posing with accessories, elegant style, professional photography'
    ]
  },
  {
    category: 'Produtos',
    prompts: [
      'Modern smartphone on wooden desk, minimalist style, professional product photography',
      'Elegant watch on marble surface, luxury lighting, high-end product shot',
      'Skincare product with natural ingredients, clean background, commercial photo',
      'Headphones on music studio desk, dramatic lighting, tech product photography'
    ]
  },
  {
    category: 'Paisagens',
    prompts: [
      'Beautiful sunset over mountains, dramatic sky, landscape photography',
      'Tropical beach with crystal clear water, palm trees, paradise scenery',
      'Urban cityscape at night, neon lights, modern architecture',
      'Forest path in autumn, colorful leaves, peaceful nature scene'
    ]
  },
  {
    category: 'Retratos',
    prompts: [
      'Professional headshot of business person, neutral background, studio lighting',
      'Artistic portrait with dramatic lighting, emotional expression',
      'Casual portrait outdoors, natural lighting, friendly atmosphere',
      'Creative portrait with colorful background, artistic style'
    ]
  },
  {
    category: 'Lifestyle',
    prompts: [
      'Cozy home office setup, laptop and coffee, morning light',
      'Fitness workout scene, gym equipment, energetic atmosphere',
      'Cooking in modern kitchen, fresh ingredients, food photography',
      'Reading book in comfortable chair, warm lighting, relaxing mood'
    ]
  }
];

export const videoTips = [
  {
    title: 'Escolha da Imagem',
    tips: [
      'Use fotos com rosto bem visível e centralizado',
      'Evite imagens muito escuras ou com sombras fortes',
      'Prefira fotos com fundo neutro ou desfocado',
      'Resolução mínima recomendada: 512x512 pixels'
    ]
  },
  {
    title: 'Escolha do Áudio',
    tips: [
      'Use áudios com voz clara e sem ruídos',
      'Duração recomendada: 5-30 segundos',
      'Formatos suportados: MP3, WAV, OGG',
      'Evite músicas com vozes misturadas'
    ]
  },
  {
    title: 'Melhores Resultados',
    tips: [
      'Imagens frontais funcionam melhor que perfis',
      'Expressões neutras ou leves sorrisos são ideais',
      'Evite óculos escuros ou acessórios que cubram o rosto',
      'Boa iluminação na foto original melhora o resultado'
    ]
  }
];

export function getRandomPrompt(category?: string): string {
  if (category) {
    const cat = imagePromptExamples.find(c => c.category === category);
    if (cat) {
      return cat.prompts[Math.floor(Math.random() * cat.prompts.length)];
    }
  }
  
  // Retorna prompt aleatório de qualquer categoria
  const allPrompts = imagePromptExamples.flatMap(c => c.prompts);
  return allPrompts[Math.floor(Math.random() * allPrompts.length)];
}
