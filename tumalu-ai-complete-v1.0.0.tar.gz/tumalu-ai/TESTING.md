# TUMALU AI - Guia de Testes

## 🧪 Testes Manuais

### 1. Teste de Geração de Imagem

#### Pré-requisitos:
- Token do Hugging Face válido
- Servidor rodando (`npm run dev`)

#### Passos:
1. Abra http://localhost:3000
2. Cole seu token HF no campo de token
3. Na aba "Gerar Imagem", insira o prompt:
   ```
   Professional influencer holding a smartphone, studio lighting
   ```
4. Clique em "Gerar Imagem"
5. Aguarde 10-30 segundos

#### Resultado Esperado:
- ✅ Loading spinner aparece
- ✅ Imagem é gerada e exibida
- ✅ Botão de download aparece
- ✅ Download funciona ao clicar

#### Possíveis Erros:
- ❌ "Token inválido" → Verifique o token
- ❌ "Rate limit" → Aguarde alguns minutos
- ❌ "Network error" → Verifique conexão

---

### 2. Teste de Geração de Vídeo

#### Pré-requisitos:
- Token do Hugging Face válido
- Imagem de rosto (JPG/PNG)
- Arquivo de áudio (MP3/WAV)
- Servidor rodando

#### Passos:
1. Abra http://localhost:3000
2. Cole seu token HF no campo de token
3. Vá para aba "Gerar Vídeo (Lip Sync)"
4. Faça upload de uma foto com rosto
5. Faça upload de um arquivo de áudio
6. Clique em "Gerar Vídeo"
7. Aguarde 2-10 minutos

#### Resultado Esperado:
- ✅ Preview da imagem aparece após upload
- ✅ Nome do áudio aparece após upload
- ✅ Loading com mensagem de progresso
- ✅ Vídeo é gerado e pode ser reproduzido
- ✅ Botão de download funciona

#### Possíveis Erros:
- ❌ "Nenhum rosto detectado" → Use foto com rosto visível
- ❌ "Arquivo muito grande" → Reduza tamanho (max 10MB)
- ❌ "Timeout" → Tente com arquivos menores

---

## 🔍 Teste de Console (Logs)

### Verificar Logs no Terminal:

```bash
# Ao gerar imagem, você deve ver:
🚀 Iniciando geração de imagem com FLUX.1-schnell...
📝 Prompt: [seu prompt]
✅ Conectado ao Space FLUX.1-schnell
✅ Imagem gerada com sucesso
📦 Resultado: [objeto com dados]

# Ao gerar vídeo, você deve ver:
🚀 Iniciando geração de vídeo com LivePortrait...
🖼️ Imagem: [nome do arquivo]
🎵 Áudio: [nome do arquivo]
✅ Conectado ao Space LivePortrait
✅ Vídeo gerado com sucesso
📦 Resultado: [objeto com dados]
```

---

## 🐛 Teste de Erros Comuns

### 1. Token Inválido
```bash
# Teste: Cole token "abc123" (inválido)
# Esperado: Erro "Token inválido" na interface
```

### 2. Prompt Vazio
```bash
# Teste: Clique em "Gerar" sem preencher prompt
# Esperado: Erro "Por favor, insira um prompt"
```

### 3. Arquivo Inválido
```bash
# Teste: Tente fazer upload de TXT como imagem
# Esperado: Arquivo não aceito ou erro de validação
```

---

## ⚡ Teste de Performance

### Tempo Esperado:
- **Imagem FLUX**: 5-30 segundos
- **Vídeo LivePortrait**: 2-10 minutos

### Se Demorar Muito:
1. Verifique conexão com internet
2. Tente novamente em horário diferente
3. Verifique se não há rate limit ativo

---

## 📊 Checklist de Funcionalidades

### Interface:
- [ ] Token pode ser colado e salvo
- [ ] Abas mudam corretamente
- [ ] Dark mode está ativo
- [ ] Responsive em mobile

### Geração de Imagem:
- [ ] Prompt aceita texto
- [ ] Botão "Gerar" funciona
- [ ] Loading aparece durante geração
- [ ] Imagem é exibida após geração
- [ ] Download funciona

### Geração de Vídeo:
- [ ] Upload de imagem funciona
- [ ] Upload de áudio funciona
- [ ] Preview da imagem aparece
- [ ] Botão "Gerar" funciona
- [ ] Loading com tempo estimado
- [ ] Vídeo é exibido após geração
- [ ] Vídeo pode ser reproduzido
- [ ] Download funciona

### Tratamento de Erros:
- [ ] Erros são exibidos claramente
- [ ] Mensagens de erro são úteis
- [ ] UI não quebra com erros

---

## 🚀 Teste de Produção

Antes de fazer deploy:

```bash
# 1. Build de produção
npm run build

# 2. Teste local de produção
npm start

# 3. Verifique se tudo funciona
# - Acesse http://localhost:3000
# - Teste geração de imagem
# - Teste geração de vídeo
```

---

## 📝 Relatório de Teste (Template)

```
Data: ___/___/2025
Testador: ________________

TESTE DE IMAGEM:
- Token válido: [ ] Sim [ ] Não
- Geração funcionou: [ ] Sim [ ] Não
- Tempo de geração: _____ segundos
- Download funcionou: [ ] Sim [ ] Não
- Observações: _________________

TESTE DE VÍDEO:
- Token válido: [ ] Sim [ ] Não
- Upload funcionou: [ ] Sim [ ] Não
- Geração funcionou: [ ] Sim [ ] Não
- Tempo de geração: _____ minutos
- Download funcionou: [ ] Sim [ ] Não
- Observações: _________________

BUGS ENCONTRADOS:
_________________________________
_________________________________

SUGESTÕES:
_________________________________
_________________________________
```
