# 🤝 Guia de Contribuição - TUMALU AI

Obrigado por considerar contribuir com o TUMALU AI! Este documento fornece diretrizes para contribuir com o projeto.

## 📋 Índice

1. [Código de Conduta](#código-de-conduta)
2. [Como Posso Contribuir?](#como-posso-contribuir)
3. [Configuração do Ambiente](#configuração-do-ambiente)
4. [Fluxo de Trabalho](#fluxo-de-trabalho)
5. [Padrões de Código](#padrões-de-código)
6. [Commits](#commits)
7. [Pull Requests](#pull-requests)

---

## 📜 Código de Conduta

Este projeto adere a um Código de Conduta que todos os contribuidores devem seguir:

- Seja respeitoso e inclusivo
- Aceite críticas construtivas
- Foque no que é melhor para a comunidade
- Mostre empatia com outros membros

---

## 🎯 Como Posso Contribuir?

### 🐛 Reportando Bugs

Antes de criar um bug report:
- Verifique se o bug já foi reportado
- Colete informações sobre o bug
- Teste com a versão mais recente

Ao criar um bug report, inclua:
```markdown
**Descrição do Bug**
Descrição clara do que aconteceu

**Para Reproduzir**
1. Vá para '...'
2. Clique em '...'
3. Role até '...'
4. Veja o erro

**Comportamento Esperado**
O que deveria acontecer

**Screenshots**
Se aplicável, adicione screenshots

**Ambiente:**
- OS: [e.g. Windows 11]
- Browser: [e.g. Chrome 120]
- Node: [e.g. 18.17.0]
- Versão: [e.g. 1.0.0]

**Contexto Adicional**
Qualquer outra informação relevante
```

### 💡 Sugerindo Funcionalidades

Para sugerir uma funcionalidade:
- Verifique se já foi sugerida
- Explique o problema que resolve
- Descreva a solução proposta
- Considere alternativas

Template de sugestão:
```markdown
**Problema**
Descrição clara do problema

**Solução Proposta**
Descrição clara da solução

**Alternativas Consideradas**
Outras soluções que foram consideradas

**Contexto Adicional**
Screenshots, mockups, exemplos
```

### 🔧 Contribuindo com Código

Áreas onde você pode contribuir:
- Corrigir bugs
- Adicionar funcionalidades
- Melhorar documentação
- Otimizar performance
- Adicionar testes
- Melhorar UI/UX

---

## 🛠️ Configuração do Ambiente

### Pré-requisitos
```bash
Node.js >= 18
npm >= 9
Git
```

### Setup
```bash
# 1. Fork o repositório no GitHub

# 2. Clone seu fork
git clone https://github.com/SEU-USERNAME/tumalu-ai.git
cd tumalu-ai

# 3. Adicione o repositório original como upstream
git remote add upstream https://github.com/ORIGINAL-USERNAME/tumalu-ai.git

# 4. Instale dependências
npm install

# 5. Crie arquivo .env.local
cp .env.example .env.local

# 6. Adicione seu token do Hugging Face

# 7. Inicie o servidor de desenvolvimento
npm run dev
```

### Verificação
```bash
# Execute o health check
node health-check.js

# Deve mostrar ✅ TUDO PRONTO!
```

---

## 🔄 Fluxo de Trabalho

### 1. Crie uma Branch
```bash
# Atualize seu main
git checkout main
git pull upstream main

# Crie uma nova branch
git checkout -b feature/nome-da-feature
# ou
git checkout -b fix/nome-do-bug
```

### 2. Faça Suas Mudanças
```bash
# Edite os arquivos necessários
# Teste suas mudanças
npm run dev
```

### 3. Teste Tudo
```bash
# Verifique se o build funciona
npm run build

# Teste a versão de produção
npm start

# Execute linter (se configurado)
npm run lint
```

### 4. Commit
```bash
git add .
git commit -m "tipo: descrição curta"
```

### 5. Push
```bash
git push origin feature/nome-da-feature
```

### 6. Abra um Pull Request
No GitHub, abra um PR do seu fork para o repositório original.

---

## 📝 Padrões de Código

### TypeScript
```typescript
// Use tipos explícitos
function generateImage(prompt: string, token: string): Promise<string> {
  // ...
}

// Use interfaces para objetos
interface ImageResult {
  url: string;
  prompt: string;
  timestamp: number;
}

// Evite 'any'
// ❌ Ruim
const result: any = await fetch(...);

// ✅ Bom
const result: ImageResult = await fetch(...);
```

### React/Next.js
```typescript
// Use 'use client' quando necessário
'use client';

// Nomeie componentes com PascalCase
export default function ImageGenerator() {
  // ...
}

// Use hooks no topo do componente
const [loading, setLoading] = useState(false);
const [error, setError] = useState<string | null>(null);

// Extraia lógica complexa para hooks customizados
const { token, saveToken } = useHuggingFaceToken();
```

### CSS/Tailwind
```tsx
// Prefira Tailwind classes
<div className="bg-gray-800 rounded-lg p-4">

// Agrupe classes relacionadas
<div className="
  flex items-center justify-between
  bg-gray-800 hover:bg-gray-700
  rounded-lg shadow-lg
  p-4 space-x-4
  transition-colors
">

// Use variáveis CSS para cores
:root {
  --color-primary: #8b5cf6;
}
```

### Estrutura de Arquivos
```
app/
├── api/              # API routes
├── components/       # Componentes reutilizáveis
├── hooks/           # Hooks customizados
├── utils/           # Funções utilitárias
├── data/            # Dados estáticos
├── types/           # Definições de tipos
└── ...
```

### Nomenclatura
```typescript
// Arquivos: kebab-case
image-generator.tsx
use-token.ts

// Componentes: PascalCase
ImageGenerator
LoadingSpinner

// Funções: camelCase
generateImage()
formatFileSize()

// Constantes: UPPER_SNAKE_CASE
MAX_FILE_SIZE
API_TIMEOUT

// Hooks: useCamelCase
useHuggingFaceToken()
useImageGeneration()
```

---

## 💬 Commits

### Formato
```
tipo(escopo): descrição curta

Descrição detalhada (opcional)

Rodapé (opcional)
```

### Tipos
- `feat`: Nova funcionalidade
- `fix`: Correção de bug
- `docs`: Documentação
- `style`: Formatação, ponto e vírgula, etc
- `refactor`: Refatoração de código
- `test`: Adicionar/modificar testes
- `chore`: Tarefas de manutenção

### Exemplos
```bash
feat(image): adicionar suporte para batch generation

fix(video): corrigir erro ao fazer upload de arquivos grandes

docs(readme): atualizar instruções de instalação

style(ui): melhorar espaçamento dos botões

refactor(api): extrair lógica de validação para helper

test(image): adicionar testes para geração de imagem

chore(deps): atualizar dependências do npm
```

---

## 🔀 Pull Requests

### Checklist Antes de Abrir PR

- [ ] Código segue os padrões do projeto
- [ ] Testes foram executados e passam
- [ ] Build de produção funciona
- [ ] Documentação foi atualizada (se necessário)
- [ ] Commits seguem o padrão
- [ ] Branch está atualizada com main
- [ ] Não há conflitos

### Template de PR

```markdown
## Descrição
Descrição clara das mudanças

## Tipo de Mudança
- [ ] Bug fix
- [ ] Nova funcionalidade
- [ ] Breaking change
- [ ] Documentação

## Como Testar?
1. Execute `npm run dev`
2. Navegue até...
3. Clique em...
4. Verifique que...

## Screenshots (se aplicável)
![descrição](url)

## Checklist
- [ ] Código testado
- [ ] Build funciona
- [ ] Documentação atualizada
- [ ] Commits seguem padrão
```

### Processo de Review

1. Mantenedor revisa o código
2. Mudanças podem ser solicitadas
3. Faça as correções necessárias
4. Push das correções
5. Aprovação final
6. Merge!

---

## 🏆 Reconhecimento

Contribuidores serão:
- Listados no README
- Mencionados no CHANGELOG
- Agradecidos publicamente

---

## 📞 Dúvidas?

- Abra uma issue com a tag `question`
- Entre em contato via discussões do GitHub
- Consulte a documentação existente

---

## 📄 Licença

Ao contribuir, você concorda que suas contribuições serão licenciadas sob a mesma licença do projeto.

---

**Obrigado por contribuir! 🎉**
