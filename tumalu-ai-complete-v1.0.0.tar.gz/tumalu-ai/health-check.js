#!/usr/bin/env node

/**
 * TUMALU AI - Health Check Script
 * Verifica se todas as dependências e configurações estão corretas
 */

const fs = require('fs');
const path = require('path');

console.log('🔍 TUMALU AI - Verificação de Saúde do Sistema\n');

let hasErrors = false;

// Verificar Node.js version
console.log('📦 Verificando Node.js...');
const nodeVersion = process.version;
const majorVersion = parseInt(nodeVersion.split('.')[0].substring(1));

if (majorVersion >= 18) {
  console.log(`✅ Node.js ${nodeVersion} - OK\n`);
} else {
  console.log(`❌ Node.js ${nodeVersion} - Versão muito antiga (necessário >= 18)\n`);
  hasErrors = true;
}

// Verificar arquivos essenciais
console.log('📄 Verificando arquivos essenciais...');
const essentialFiles = [
  'package.json',
  'next.config.js',
  'tsconfig.json',
  'tailwind.config.js',
  'app/page.tsx',
  'app/layout.tsx',
  'app/api/generate-image/route.ts',
  'app/api/generate-video/route.ts',
];

let missingFiles = [];
essentialFiles.forEach(file => {
  if (fs.existsSync(file)) {
    console.log(`✅ ${file}`);
  } else {
    console.log(`❌ ${file} - FALTANDO`);
    missingFiles.push(file);
    hasErrors = true;
  }
});
console.log('');

// Verificar node_modules
console.log('📚 Verificando dependências...');
if (fs.existsSync('node_modules')) {
  console.log('✅ node_modules encontrado\n');
  
  // Verificar dependências críticas
  const criticalDeps = [
    'next',
    'react',
    '@gradio/client',
    'lucide-react',
  ];
  
  criticalDeps.forEach(dep => {
    const depPath = path.join('node_modules', dep);
    if (fs.existsSync(depPath)) {
      console.log(`✅ ${dep}`);
    } else {
      console.log(`❌ ${dep} - NÃO INSTALADO`);
      hasErrors = true;
    }
  });
  console.log('');
} else {
  console.log('❌ node_modules não encontrado - Execute: npm install\n');
  hasErrors = true;
}

// Verificar package.json
console.log('🔧 Verificando package.json...');
try {
  const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
  
  if (pkg.dependencies['@gradio/client']) {
    console.log('✅ @gradio/client configurado');
  } else {
    console.log('❌ @gradio/client não encontrado em dependencies');
    hasErrors = true;
  }
  
  if (pkg.scripts.dev && pkg.scripts.build && pkg.scripts.start) {
    console.log('✅ Scripts npm configurados');
  } else {
    console.log('❌ Scripts npm incompletos');
    hasErrors = true;
  }
  console.log('');
} catch (error) {
  console.log('❌ Erro ao ler package.json\n');
  hasErrors = true;
}

// Verificar estrutura de pastas
console.log('📁 Verificando estrutura de pastas...');
const requiredDirs = [
  'app',
  'app/api',
  'app/api/generate-image',
  'app/api/generate-video',
];

requiredDirs.forEach(dir => {
  if (fs.existsSync(dir)) {
    console.log(`✅ ${dir}/`);
  } else {
    console.log(`❌ ${dir}/ - FALTANDO`);
    hasErrors = true;
  }
});
console.log('');

// Verificar .env.example
console.log('⚙️ Verificando configurações...');
if (fs.existsSync('.env.example')) {
  console.log('✅ .env.example encontrado');
} else {
  console.log('⚠️ .env.example não encontrado (opcional)');
}

if (fs.existsSync('.env.local')) {
  console.log('✅ .env.local configurado');
} else {
  console.log('ℹ️ .env.local não encontrado (opcional - token pode ser inserido na interface)');
}
console.log('');

// Resultado final
console.log('═══════════════════════════════════════════════════\n');

if (hasErrors) {
  console.log('❌ VERIFICAÇÃO FALHOU - Corrija os erros acima\n');
  console.log('💡 Dicas:');
  if (missingFiles.length > 0) {
    console.log('   • Certifique-se de que está no diretório correto');
    console.log('   • Extraia completamente o arquivo do projeto');
  }
  if (!fs.existsSync('node_modules')) {
    console.log('   • Execute: npm install');
  }
  console.log('');
  process.exit(1);
} else {
  console.log('✅ TUDO PRONTO!\n');
  console.log('🚀 Próximos passos:');
  console.log('   1. Execute: npm run dev');
  console.log('   2. Abra: http://localhost:3000');
  console.log('   3. Obtenha seu token: https://huggingface.co/settings/tokens');
  console.log('   4. Cole o token na interface');
  console.log('   5. Comece a gerar conteúdo!\n');
  process.exit(0);
}
